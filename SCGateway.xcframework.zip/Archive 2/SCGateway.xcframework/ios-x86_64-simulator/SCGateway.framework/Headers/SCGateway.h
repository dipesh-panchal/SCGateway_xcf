//
//  SCGateway.h
//  SCGateway
//
//  Created by Shivani on 06/11/19.
//  Copyright © 2019 smallcase. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SCGateway/SCGateway.h>


@class SCGateway;
@class ObjCTransactionIntentConnect;
@class ObjcTransactionIntentTransaction;
@class ObjcTransactionIntentHoldingsImport;

FOUNDATION_EXPORT double SCGatewayVersionNumber;


//! Project version string for SCGateway.
FOUNDATION_EXPORT const unsigned char SCGatewayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SCGateway/PublicHeader.h>


